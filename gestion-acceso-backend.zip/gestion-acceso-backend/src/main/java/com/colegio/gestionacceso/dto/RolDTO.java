package com.colegio.gestionacceso.dto;

import jakarta.validation.constraints.NotBlank;

public class RolDTO {

    private Long id;

    @NotBlank(message = "El nombre del rol es requerido")
    private String nombre;

    private String descripcion;

    public RolDTO() {}

    public RolDTO(Long id, String nombre, String descripcion) {
        this.id = id;
        this.nombre = nombre;
        this.descripcion = descripcion;
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public String getDescripcion() { return descripcion; }
    public void setDescripcion(String descripcion) { this.descripcion = descripcion; }
}
